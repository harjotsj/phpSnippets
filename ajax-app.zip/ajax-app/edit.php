<?php
require("connect.php");
$id=$_REQUEST['id'];

$getdata=mysqli_query($conn,"select * from reg_users where reg_id='$id'");
	$resdata=mysqli_fetch_array($getdata,MYSQLI_ASSOC) ;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Register</title>
</head>
<body>
<form method="post">
<input type="hidden" name="edit_id" value="<?php echo $id;?>"/>
<table width="500" style="padding-top:20px; font-size:12px;">
  <tr>
    <td colspan="2" style="width:200px; font-size:14px; font-weight:bold; padding-left:300px;">PERSONAL DETAILS</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">First Name :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" name="fname" size="40" value="<?php echo $resdata['reg_fname'];?>" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Last Name :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" name="lname" size="40" value="<?php echo $resdata['reg_lname'];?>" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
   
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Email :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" name="email" value="<?php echo $resdata['reg_email'];?>" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Phone :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" value="<?php echo $resdata['reg_phone'];?>" name="phone" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" style="width:200px; padding-left:300px;"><input type="submit" name="add" value="Update" size="40" class="button" maxlength="100">
      &nbsp;
      <input type="reset" class="button" name="cancel" value="Cancel" size="40" maxlength="100">
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>

</body>
</html>
