/*Form validation js code starts here*/
function record_validation(){ 
		if(document.add_users.fname.value==''){
		    alert('please Enter First Name');
			document.add_users.fname.focus();
		    return false;
		}
		 else if(document.add_users.lname.value==''){
		    alert('please Enter Last Name');
			document.add_users.lname.focus();
		    return false;
		}
		else if(document.add_users.email.value==''){
		    alert('please Enter Email');
			document.add_users.email.focus();
		    return false;
		}
		else if(document.add_users.phone.value==''){
		    alert('please Enter Phone');
			document.add_users.phone.focus();
		    return false;
		}
		
		else {
			  return true;
		}
		
	}
	/*Form validation js code ends here*/
	
/*Record edited through ajax code starts here*/
function brand_edit(reg_id){
	//alert(reg_id);
	var fname=$('#fname').val();
	var lname=$('#lname').val();
	var email=$('#email').val();
	var phone=$('#phone').val();
	$.ajax({	
		url:'edit.php?id='+reg_id+'&fname='+fname+'&lname='+lname+'&email='+email+'&phone='+phone,
		
		type:'POST',
		success:function(getData)
		{
			//alert(getData);
			$('#main_divId').hide();
			$("#record_update").show();
			$("#record_update").html(getData);
		}
		});	
		var div_value=document.getElementById("#record_update").value;
		document.getElementById("record_update").innerHTML="div_value";
		//alert(div_value);
	}

/*Record edited through ajax code ends here*/