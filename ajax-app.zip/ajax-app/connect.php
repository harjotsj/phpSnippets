<?php
error_reporting(0);
$host="localhost";
$user="root";
$pass="";
$db="ajax_app";
$conn=mysqli_connect($host,$user,$pass,$db) or die (mysql_error());

?>