<?php
require("connect.php");
$delid=$_REQUEST['del'];
if($delid!=''){
$delete="delete from reg_users where reg_id='$delid'";
mysqli_query($conn,$delete) or die(mysqli_error());
echo "<script>location.href='index.php?delt=yes'</script>";

}
if($_REQUEST['delt']!=''){
$msg="Record Deleted Successfully";
}
if($_POST['add']=='Update'){

$fname1=$_REQUEST['fname'];
$lname1=$_REQUEST['lname'];
$email1=$_REQUEST['email'];
$phone1=$_REQUEST['phone'];
$edit_id=$_REQUEST['edit_id'];

$update="update reg_users set 
	reg_fname='$fname1',
	reg_lname='$lname1',
	reg_email='$email1',
	reg_phone='$phone1' where reg_id='$edit_id'";
	mysqli_query($conn,$update) or die(mysqli_error());
	echo "<script>location.href='index.php?updt=yes'</script>";
}
if($_REQUEST['updt']!=''){
$msg="Record Updated Successfully";
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Register</title>
<link href="css/style.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="js/functions.js"></script>
</head>

<body>

<div id="record_update" style="width:600px;  height:279px; background-color:#FFFFFF; display:none;">        
</div>

<?php
if($_REQUEST['sucs']!=''){
$msg="Record Added Successfully";
}
if($_POST['register']=='Register'){
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$phone=$_POST['phone'];

$insert="insert into reg_users set 
	reg_fname='$fname',
	reg_lname='$lname',
	reg_email='$email',
	reg_phone='$phone'";
	mysqli_query($conn,$insert) or die(mysqli_error());
	echo "<script>location.href='index.php?sucs=yes'</script>";
}
?>
<div id="main_divId">
<form method="post" name="add_users" onSubmit="return record_validation(this);">
<input type="hidden" name="none" value="g"/>
<table width="500" style="padding-top:20px; font-size:12px;">
  <tr>
    <td colspan="2" style="width:200px; font-size:14px; font-weight:bold; padding-left:300px;">PERSONAL DETAILS</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">First Name :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" id="fname" name="fname" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Last Name :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" id="lname" name="lname" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
   
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Email :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" id="email" name="email" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
  <tr>
    <td class="key" style="width:240px; padding-right:10px; text-align:right;">Phone :</td>
    <td style="width:230px; padding-left:20px;"><input type="text" id="phone" name="phone" size="40" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" style="width:200px; padding-left:300px;"><input type="submit" class="button" name="register" value="Register" size="40" maxlength="100">
      &nbsp;
      <input type="reset" class="button" name="cancel" value="Cancel" size="40" maxlength="100">
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>
</div>

<div align="center" style="width:100%; border:1px solid black; text-align:center;">
<?php
$select="select * from reg_users";
$sql_sel=mysqli_query($conn,$select) or die(mysqli_error());
$num_rows=mysqli_num_rows($sql_sel);
if($num_rows>0){
?>

<h2>List of Records</h2>
<table border="1" style="width:100%; text-align:center;" cellpadding="5" cellspacing="0">
<tr>
<th>S.No</th>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
<th>Phone</th>
<th>Operations</th>
</tr>
<?php

$i=1;
while($rec=mysqli_fetch_array($sql_sel,MYSQLI_ASSOC)){

?>
<tr>
<td><?php echo $i;?></td>
<td><?php echo $rec['reg_fname'] ;?></td>
<td><?php echo $rec['reg_lname'] ;?></td>
<td><?php echo $rec['reg_email'] ;?></td>
<td><?php echo $rec['reg_phone'] ;?></td>
<?php 
 echo "<td>
   <a id='edit_close' style='cursor:pointer;' onclick=\"brand_edit('".$rec['reg_id']."')\"><img  src='images/pencil.gif' width='16' height='16' alt='edit' /></a>&nbsp;&nbsp;
                                  <a href='index.php?del=".$rec['reg_id'] ."' onClick=\"return confirm('do you want to delete?')\"><img src='images/icn_trash.png' width='16' height='16' alt='comments' /></a>
								  </td>";
								   ?>

</tr>
<?php $i++;}?>

</table>
<?php }else{ echo '<div style="color:red; text-align:center;">No Record Found</div>';}?>
</div>
<div>&nbsp;</div>
<div style="font-size:16px; width:50%; color:#990000;  text-align:right;"><?php echo $msg; ?></div>
<div align="right" ><a href="index.php" style="font-size:26px; color:green; width:50%;  text-align:right; text-decoration:none;">Home</a></div>

</body>
</html>
